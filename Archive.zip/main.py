from fastapi import FastAPI
from app.api.v1.router import router

app = FastAPI(title="Culture Simulation v2")
app.include_router(router, prefix="/v1")
