from pydantic import BaseModel
from typing import List, Dict


class SeverityHints(BaseModel):
    emotional_intensity: str  # low | moderate | high
    scope: str                # individual | team | org
    urgency: str              # low | medium | high


class NLPNormalizationResult(BaseModel):
    clean_problem_statement: str
    signals: List[str]
    taxonomy: Dict[str, List[str]]
    severity_hints: SeverityHints
