from fastapi import APIRouter
from pydantic import BaseModel
from app.services.pipeline import run_pipeline

router = APIRouter()

class AnalyzeRequest(BaseModel):
    problem_text: str

@router.post("/analyze")
async def analyze(req: AnalyzeRequest):
    return await run_pipeline(req.problem_text)
